A simple library for interfacing a matrix keypad with the Raspberry Pi, using interrupts.
Originally based on the library from here: https://pypi.python.org/pypi/matrix_keypad